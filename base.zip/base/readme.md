## Notas iniciales:
- Este compose inicia un servicio llamado "bddpostgres"
- La conexion a la BDD se la realizará en el puerto local "5432" puede modificarse en el archivo "docker-compose.yml"
- Se generan dos volumenes docker, estos son:
  - "postgres-backups" -> En el host, esta carpeta debe estar ubicada en el mismo path del archivo "docker-compose.yml", estas carpeta va a contener los DMP para importar en la BDD del contenedor.
  - "onlinestore-dbdata" -> Esta carpeta servirá para persistir la BDD en nuestro local, es decir va a contener toda la data de la BDD, esta carpeta no tiene una referencia en el path del proyecto ya que en windows existen problemas de permisos al generar un volumen por referencia para "/var/lib/postgresql/data/", por lo que es necesario generar un volumen externo en docker, y este debe ser creado de forma manual.
    
#### Creacion manual del volumen de referencia a data
Para crear el volumen "postgres-data" se debe ejecutar el siguiente comando:
  docker
    docker volume create --name=postgres-data
  
#### Eliminacion manual del volumen de referencia a data
En el caso de que se tenga la necesidad de eliminar el data del host se debe:
- Verificar que el contenedor que haga referencia a este volumen no este arriba
- Eliminar el contenedor que haga referencia a este volumen no este arriba
- Eliminarlo con el siguiente comando:
  docker
    docker volume rm postgres-data
  
- NOTA: para levantar otra vez el servicio se debe volver a crear el volumen

## Primera ejecucion
- Iniciar una terminal en el path donde se encuentra el archivo "docker-compose.yml"
- Iniciaremos el servicio con el comando:
  docker
    docker-compose up
  
- La primera ejecución puede tardar unos segundos puesto que generará la data respectiva.  

#### Ingresar en el contenedor  
- Para ingresar en el contenedor, en un contenedor ejecutar el comando:
  docker
    docker-compose exec bddpostgres bash
  
- Tener en cuenta que al ingresar al contenedor ingresamos al SO del mismo

#### Ingresar a la linea de comandos postgres 
- Para ingresar de manera general sin ingresar a una BDD especifica usamos:
  unix
    psql --host=localhost --username=postgres
  
- Para ingresar conectandose a una BDD especifica usamos: (mi_base no se ha creado aun)
  unix
    psql --host=localhost --username=postgres --dbname=mi_base
  
## Importar un DMP 
### Lo siguiente se ejecutará en PSQL
- Crear el tablespace necesario
postgres=# CREATE DATABASE mi_base ENCODING 'UTF8';

- Cambiarse a una bdd especifica
postgres=# \c mi_base 

- Ejecutar un archivo .sql
postgres=# \i /var/lib/postgresql/backupsExt/1_db_backup.sql
select * from bank;
----
- listar todos los tablespaces:
postgres=# \db+

  
========================================
docker-compose ps
docker-compose exec bddpostgres bash
### SQL Iniciales
```sql
postgres=# CREATE DATABASE mi_base ENCODING 'UTF8';
CREATE TABLE IF NOT EXISTS accounts (id serial PRIMARY KEY,username VARCHAR (255) UNIQUE NOT NULL);
INSERT INTO accounts(username) VALUES ('rick'), ('morty') RETURNING *;

```


psql --host=localhost --username=postgres
CREATE DATABASE onlinedb ENCODING 'UTF8';
\c onlinedb


docker-compose exec bddpostgres cd /var/lib/posrgresql/backupsExt ./init.sh
