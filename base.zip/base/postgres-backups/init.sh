
source $PATH_EXTERNAL/functions.sh
validaExistDb
retValidaExistDb=$?
if [ $retValidaExistDb -eq 0 ] ; then 
    initDataBase
    retInitDataBase=$?
else
    echo "SI EXISTE"
fi



