function validaExistDb {
VALUE=$(
psql --host=localhost --username=postgres << EOF
SELECT FROM pg_database WHERE datname = 'onlinedb'
EOF
)
    echo $VALUE
    if [[ $VALUE == *"1"* ]]; then
    return 1;
    else
    return 0;
    fi
}

function initDataBase {
VALUE=$(
psql --host=localhost --username=postgres << EOF
CREATE DATABASE onlinedb ENCODING 'UTF8';
\c onlinedb

CREATE TABLE IF NOT EXISTS users (
    id serial PRIMARY KEY,
    username VARCHAR (255) UNIQUE NOT NULL, 
    name VARCHAR (50), 
    lastname VARCHAR (100) , 
    mail VARCHAR (100) UNIQUE NOT NULL);

INSERT INTO users(username, name, lastname, mail)  VALUES 
('gabo','Gabriel', 'Mafla', 'gm@gmail.com'), 
('rodri','Rodrigo', 'Ipial', 'ri@gmail.com'), 
('rccs','Roberto', 'Cadena', 'rc@gmail.com') RETURNING *;
EOF
)

echo $VALUE
if [[ $VALUE == *"1"* ]]; then
  return 1;
else
  return 0;
fi
}